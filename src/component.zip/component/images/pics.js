import loginImage from './login.svg'
import signUpImage from './register.svg'

const imgSrc = {
    loginImage,
    signUpImage
}

export default imgSrc