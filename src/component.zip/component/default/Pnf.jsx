import React from 'react'

function Pnf(props) {
  return (
    <div>
      Page Not Found
    </div>
  )
}

export default Pnf
