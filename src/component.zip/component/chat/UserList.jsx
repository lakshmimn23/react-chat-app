import React from 'react'

function UserList() {
  return (
    <div>
      UserList
    </div>
  )
}

export default UserList
