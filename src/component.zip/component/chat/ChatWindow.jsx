import React from 'react'
import "./css/chatWindow.scss"

function ChatWindow() {
  return (
    <div className='right-side'>
      Chat Window
    </div>
  )
}

export default ChatWindow
